import pandas as pd
import os

def main():
    print("Loading data for verification...")
    base_dir = os.path.dirname(__file__)
    quality_path = os.path.join(base_dir, "../output/review_quality_scores.csv")
    pagerank_path = os.path.join(base_dir, "../output/submission.csv")
    
    try:
        quality_df = pd.read_csv(quality_path)
        pr_df = pd.read_csv(pagerank_path)
    except FileNotFoundError as e:
        print(f"Error loading files: {e}")
        return

    print("Merging and processing...")
    merged = pd.merge(quality_df, pr_df, left_on='reviewerID', right_on='userId', how='inner')
    
    if merged.empty:
        print("No intersecting users found. Cannot proceed.")
        return

    merged['Value'] = merged['pagerank'] * merged['quality_score']
    
    # Convert timestamp to month
    merged['date'] = pd.to_datetime(merged['unixReviewTime'], unit='s')
    merged['month'] = merged['date'].dt.to_period('M')
    
    top_products = merged['asin'].value_counts().head(2).index.tolist()
    
    # Filter for the top 2 products
    filtered = merged[merged['asin'].isin(top_products)]
    
    # Save the raw merged data to a CSV so the math can be manually verified
    verification_path = os.path.join(base_dir, "../output/verification_data.csv")
    filtered.to_csv(verification_path, index=False)
    
    print(f"Done ✅ Raw verification data saved to {verification_path}")

if __name__ == "__main__":
    main()
