import networkx as nx

def compute_pagerank(G):
    print("Running PageRank...")
    pr = nx.pagerank(G, weight='weight', max_iter=50)
    
    # Scale to 0-1 range
    if pr:
        min_pr = min(pr.values())
        max_pr = max(pr.values())
        if max_pr > min_pr:
            pr = {node: (score - min_pr) / (max_pr - min_pr) for node, score in pr.items()}
        else:
            pr = {node: 0.0 for node in pr.keys()}
            
    return pr