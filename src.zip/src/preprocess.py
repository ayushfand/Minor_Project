def preprocess(df):
    # Map the JSON columns to the names expected by the rest of the pipeline
    df = df[['asin', 'reviewerID', 'unixReviewTime']].copy()
    df.rename(columns={
        'asin': 'product/productId',
        'reviewerID': 'review/userId',
        'unixReviewTime': 'review/time'
    }, inplace=True)

    # Filter out empty or unknown users
    df = df[df['review/userId'].notna()]
    df = df[df['review/userId'] != 'unknown']

    df['review/time'] = df['review/time'].fillna(0).astype('int32')

    return df