import pandas as pd
import json

def load_sample_data(file_path, max_records=20000):
    records = []

    with open(file_path, 'r', encoding='utf-8') as f:
        for i, line in enumerate(f):
            if i >= max_records:
                break
            try:
                records.append(json.loads(line))
            except json.JSONDecodeError:
                continue

    print("Loaded records:", len(records))
    return pd.DataFrame(records)