import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

def main():
    print("Loading data...")
    # Paths
    base_dir = os.path.dirname(__file__)
    quality_path = os.path.join(base_dir, "../output/review_quality_scores.csv")
    pagerank_path = os.path.join(base_dir, "../output/submission.csv")
    
    # Load
    try:
        quality_df = pd.read_csv(quality_path)
        pr_df = pd.read_csv(pagerank_path)
    except FileNotFoundError as e:
        print(f"Error loading files: {e}")
        return

    print("Merging and processing...")
    # Merge on user ID
    # quality_df has 'reviewerID', pr_df has 'userId'
    merged = pd.merge(quality_df, pr_df, left_on='reviewerID', right_on='userId', how='inner')
    
    if merged.empty:
        print("No intersecting users found. Cannot proceed.")
        return

    # Calculate Value
    merged['Value'] = merged['pagerank'] * merged['quality_score']
    
    # Convert timestamp to month
    merged['date'] = pd.to_datetime(merged['unixReviewTime'], unit='s')
    merged['month'] = merged['date'].dt.to_period('M')
    
    # Select 2 products with many reviews
    # To be safe, we dynamically select the top 2 products with the most data in our merged subset
    top_products = merged['asin'].value_counts().head(2).index.tolist()
    print(f"Plotting for top products: {top_products}")
    
    # Filter for these products
    filtered = merged[merged['asin'].isin(top_products)]
    
    # Group by product and month, then average the value
    monthly_avg = filtered.groupby(['asin', 'month'])['Value'].mean().reset_index()
    monthly_avg['month'] = monthly_avg['month'].astype(str) # convert period to string for plotting
    
    # Sort chronologically
    monthly_avg = monthly_avg.sort_values('month')

    # To get a 2-year continuous period, we can take the most recent 24 months
    # Or just plot all available months. Let's plot the last 24 months present in the data.
    unique_months = sorted(monthly_avg['month'].unique())
    if len(unique_months) > 24:
        last_24_months = unique_months[-24:]
        monthly_avg = monthly_avg[monthly_avg['month'].isin(last_24_months)]

    print("Generating plot...")
    plt.figure(figsize=(10, 6))
    sns.lineplot(data=monthly_avg, x='month', y='Value', hue='asin', marker='o', linewidth=2.5)
    
    plt.title('Monthly Average Product Value (PageRank x Review Quality)', fontsize=14)
    plt.xlabel('Month', fontsize=12)
    plt.ylabel('Average Value', fontsize=12)
    plt.xticks(rotation=45)
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.tight_layout()
    
    # Save plot
    output_dir = os.path.join(base_dir, "../output")
    os.makedirs(output_dir, exist_ok=True)
    plot_path = os.path.join(output_dir, "product_value_over_time.png")
    
    plt.savefig(plot_path, dpi=300)
    print(f"Done ✅ Plot saved to {plot_path}")

if __name__ == "__main__":
    main()
